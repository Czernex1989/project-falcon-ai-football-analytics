# Portfolio Project Summaries

This folder will contain short summaries of completed Project FALCON portfolio work.

Planned projects:

1. SQL Football Mini Analysis
2. Python Match Data Notebook
3. Football Match Report
4. Player Profile Report
5. FALCON Progress Log
