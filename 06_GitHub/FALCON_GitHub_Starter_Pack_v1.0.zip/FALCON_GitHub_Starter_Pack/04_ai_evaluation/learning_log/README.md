# AI Evaluation Learning Log

General notes about AI evaluation, search quality, guideline-based work and learning progress.

Do not publish screenshots, private platform materials, task contents, client data or anything covered by NDA or platform rules.
